﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.Calcular = New System.Windows.Forms.Button
        Me.Tb6 = New System.Windows.Forms.TextBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.Label7 = New System.Windows.Forms.Label
        Me.Tb3 = New System.Windows.Forms.TextBox
        Me.Tb2 = New System.Windows.Forms.TextBox
        Me.Tb1 = New System.Windows.Forms.TextBox
        Me.Label6 = New System.Windows.Forms.Label
        Me.Label4 = New System.Windows.Forms.Label
        Me.Label5 = New System.Windows.Forms.Label
        Me.Tb4 = New System.Windows.Forms.TextBox
        Me.Tb5 = New System.Windows.Forms.TextBox
        Me.Label0 = New System.Windows.Forms.Label
        Me.Limpar = New System.Windows.Forms.Button
        Me.Sair = New System.Windows.Forms.Button
        Me.SuspendLayout()
        '
        'Calcular
        '
        Me.Calcular.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Calcular.Location = New System.Drawing.Point(443, 221)
        Me.Calcular.Name = "Calcular"
        Me.Calcular.Size = New System.Drawing.Size(93, 30)
        Me.Calcular.TabIndex = 4
        Me.Calcular.Text = "&Calcular"
        Me.Calcular.UseVisualStyleBackColor = True
        '
        'Tb6
        '
        Me.Tb6.BackColor = System.Drawing.Color.White
        Me.Tb6.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Tb6.Location = New System.Drawing.Point(225, 373)
        Me.Tb6.Name = "Tb6"
        Me.Tb6.ReadOnly = True
        Me.Tb6.Size = New System.Drawing.Size(128, 20)
        Me.Tb6.TabIndex = 0
        Me.Tb6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(13, 112)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(206, 20)
        Me.Label1.TabIndex = 4
        Me.Label1.Text = "Hora Trabalhada no Mês"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(12, 163)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(143, 20)
        Me.Label2.TabIndex = 5
        Me.Label2.Text = "Hora Trabalhada"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(12, 212)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(202, 20)
        Me.Label3.TabIndex = 6
        Me.Label3.Text = "Percentual de Desconto"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(538, 373)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(140, 20)
        Me.Label7.TabIndex = 7
        Me.Label7.Text = "Rubia Helena 2ºW"
        '
        'Tb3
        '
        Me.Tb3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Tb3.Location = New System.Drawing.Point(240, 212)
        Me.Tb3.Name = "Tb3"
        Me.Tb3.Size = New System.Drawing.Size(139, 20)
        Me.Tb3.TabIndex = 3
        Me.Tb3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Tb2
        '
        Me.Tb2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Tb2.Location = New System.Drawing.Point(240, 163)
        Me.Tb2.Name = "Tb2"
        Me.Tb2.Size = New System.Drawing.Size(139, 20)
        Me.Tb2.TabIndex = 2
        Me.Tb2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Tb1
        '
        Me.Tb1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Tb1.Location = New System.Drawing.Point(240, 112)
        Me.Tb1.Name = "Tb1"
        Me.Tb1.Size = New System.Drawing.Size(139, 20)
        Me.Tb1.TabIndex = 1
        Me.Tb1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(388, 320)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(128, 20)
        Me.Label6.TabIndex = 11
        Me.Label6.Text = "Salário Líquido"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(56, 320)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(114, 20)
        Me.Label4.TabIndex = 12
        Me.Label4.Text = "Salário Bruto"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(208, 320)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(161, 20)
        Me.Label5.TabIndex = 13
        Me.Label5.Text = "Total de Desconto "
        '
        'Tb4
        '
        Me.Tb4.BackColor = System.Drawing.Color.White
        Me.Tb4.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Tb4.Location = New System.Drawing.Point(50, 373)
        Me.Tb4.Name = "Tb4"
        Me.Tb4.ReadOnly = True
        Me.Tb4.Size = New System.Drawing.Size(128, 20)
        Me.Tb4.TabIndex = 0
        Me.Tb4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Tb5
        '
        Me.Tb5.BackColor = System.Drawing.Color.White
        Me.Tb5.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Tb5.Location = New System.Drawing.Point(392, 373)
        Me.Tb5.Name = "Tb5"
        Me.Tb5.ReadOnly = True
        Me.Tb5.Size = New System.Drawing.Size(124, 20)
        Me.Tb5.TabIndex = 0
        Me.Tb5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label0
        '
        Me.Label0.AutoSize = True
        Me.Label0.BackColor = System.Drawing.SystemColors.Window
        Me.Label0.Font = New System.Drawing.Font("Times New Roman", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label0.Location = New System.Drawing.Point(178, 18)
        Me.Label0.Name = "Label0"
        Me.Label0.Size = New System.Drawing.Size(376, 31)
        Me.Label0.TabIndex = 14
        Me.Label0.Text = "Insira as seguintes infomações:"
        '
        'Limpar
        '
        Me.Limpar.BackgroundImage = Global.WindowsApplication1.My.Resources.Resources.TRASH01
        Me.Limpar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.Limpar.Location = New System.Drawing.Point(571, 253)
        Me.Limpar.Name = "Limpar"
        Me.Limpar.Size = New System.Drawing.Size(82, 42)
        Me.Limpar.TabIndex = 5
        Me.Limpar.UseVisualStyleBackColor = True
        '
        'Sair
        '
        Me.Sair.BackgroundImage = Global.WindowsApplication1.My.Resources.Resources.W95MBX011
        Me.Sair.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.Sair.Location = New System.Drawing.Point(571, 312)
        Me.Sair.Name = "Sair"
        Me.Sair.Size = New System.Drawing.Size(82, 39)
        Me.Sair.TabIndex = 6
        Me.Sair.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(690, 415)
        Me.Controls.Add(Me.Label0)
        Me.Controls.Add(Me.Tb5)
        Me.Controls.Add(Me.Tb4)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Tb1)
        Me.Controls.Add(Me.Tb2)
        Me.Controls.Add(Me.Tb3)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Tb6)
        Me.Controls.Add(Me.Calcular)
        Me.Controls.Add(Me.Limpar)
        Me.Controls.Add(Me.Sair)
        Me.DoubleBuffered = True
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Sair As System.Windows.Forms.Button
    Friend WithEvents Limpar As System.Windows.Forms.Button
    Friend WithEvents Calcular As System.Windows.Forms.Button
    Friend WithEvents Tb6 As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Tb3 As System.Windows.Forms.TextBox
    Friend WithEvents Tb2 As System.Windows.Forms.TextBox
    Friend WithEvents Tb1 As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Tb4 As System.Windows.Forms.TextBox
    Friend WithEvents Tb5 As System.Windows.Forms.TextBox
    Friend WithEvents Label0 As System.Windows.Forms.Label

End Class
