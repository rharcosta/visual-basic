﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmPrin
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FrmPrin))
        Me.ContextMenuStrip1 = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.CadastroToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem
        Me.LocatariosToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem
        Me.FuncionáriosToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripSeparator2 = New System.Windows.Forms.ToolStripSeparator
        Me.LivrosToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem
        Me.EditoriaToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ProjetosToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem
        Me.TabelaPeriódicaToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem
        Me.TabelaDeÂnionsECátionsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripSeparator8 = New System.Windows.Forms.ToolStripSeparator
        Me.LivrosToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem
        Me.EditoraToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.FerramentasÚteisToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.CalendárioToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem
        Me.CalculadoraToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.SobreToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem
        Me.AQuímicaToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.OProjetoToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ODesenvolvedorToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ContatoToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem
        Me.ContatoToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem
        Me.SairToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem
        Me.StatusStrip1 = New System.Windows.Forms.StatusStrip
        Me.ToolStripStatusLabel2 = New System.Windows.Forms.ToolStripStatusLabel
        Me.ToolStripStatusLabel1 = New System.Windows.Forms.ToolStripStatusLabel
        Me.ToolStripStatusLabel3 = New System.Windows.Forms.ToolStripStatusLabel
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip
        Me.CadastroToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.LocatarioToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.FuncionarioToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripSeparator9 = New System.Windows.Forms.ToolStripSeparator
        Me.LivrosToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.EditorasToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ConsultaToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.LocatariosToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.FuncionariosToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator
        Me.LivroToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.WordToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ManutencaoToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.LocacaoToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.DevolucaoToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.SobreToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.QuímicaToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.PropostaToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.DesenvolvedorToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ContatoToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ArquivoToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.SairToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.ToolStrip1 = New System.Windows.Forms.ToolStrip
        Me.ToolStripButton2 = New System.Windows.Forms.ToolStripButton
        Me.ToolStripButton4 = New System.Windows.Forms.ToolStripButton
        Me.ToolStripButton13 = New System.Windows.Forms.ToolStripButton
        Me.ToolStripSeparator3 = New System.Windows.Forms.ToolStripSeparator
        Me.ToolStripButton3 = New System.Windows.Forms.ToolStripButton
        Me.ToolStripButton12 = New System.Windows.Forms.ToolStripButton
        Me.ToolStripSeparator5 = New System.Windows.Forms.ToolStripSeparator
        Me.ToolStripButton1 = New System.Windows.Forms.ToolStripButton
        Me.ToolStripButton11 = New System.Windows.Forms.ToolStripButton
        Me.ToolStripSeparator4 = New System.Windows.Forms.ToolStripSeparator
        Me.ToolStripButton8 = New System.Windows.Forms.ToolStripButton
        Me.ToolStripSeparator7 = New System.Windows.Forms.ToolStripSeparator
        Me.ToolStripSeparator6 = New System.Windows.Forms.ToolStripSeparator
        Me.ContextMenuStrip1.SuspendLayout()
        Me.StatusStrip1.SuspendLayout()
        Me.MenuStrip1.SuspendLayout()
        Me.ToolStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'ContextMenuStrip1
        '
        Me.ContextMenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.CadastroToolStripMenuItem1, Me.ProjetosToolStripMenuItem1, Me.FerramentasÚteisToolStripMenuItem, Me.SobreToolStripMenuItem1, Me.ContatoToolStripMenuItem1})
        Me.ContextMenuStrip1.Name = "ContextMenuStrip1"
        Me.ContextMenuStrip1.Size = New System.Drawing.Size(134, 114)
        '
        'CadastroToolStripMenuItem1
        '
        Me.CadastroToolStripMenuItem1.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.LocatariosToolStripMenuItem1, Me.FuncionáriosToolStripMenuItem, Me.ToolStripSeparator2, Me.LivrosToolStripMenuItem1, Me.EditoriaToolStripMenuItem})
        Me.CadastroToolStripMenuItem1.Image = CType(resources.GetObject("CadastroToolStripMenuItem1.Image"), System.Drawing.Image)
        Me.CadastroToolStripMenuItem1.Name = "CadastroToolStripMenuItem1"
        Me.CadastroToolStripMenuItem1.Size = New System.Drawing.Size(133, 22)
        Me.CadastroToolStripMenuItem1.Text = "Cadastro"
        Me.CadastroToolStripMenuItem1.ToolTipText = "Cadastro"
        '
        'LocatariosToolStripMenuItem1
        '
        Me.LocatariosToolStripMenuItem1.Image = CType(resources.GetObject("LocatariosToolStripMenuItem1.Image"), System.Drawing.Image)
        Me.LocatariosToolStripMenuItem1.Name = "LocatariosToolStripMenuItem1"
        Me.LocatariosToolStripMenuItem1.Size = New System.Drawing.Size(134, 22)
        Me.LocatariosToolStripMenuItem1.Text = "Locatários"
        Me.LocatariosToolStripMenuItem1.ToolTipText = "Locatários"
        '
        'FuncionáriosToolStripMenuItem
        '
        Me.FuncionáriosToolStripMenuItem.Image = CType(resources.GetObject("FuncionáriosToolStripMenuItem.Image"), System.Drawing.Image)
        Me.FuncionáriosToolStripMenuItem.Name = "FuncionáriosToolStripMenuItem"
        Me.FuncionáriosToolStripMenuItem.Size = New System.Drawing.Size(134, 22)
        Me.FuncionáriosToolStripMenuItem.Text = "Funcionários"
        Me.FuncionáriosToolStripMenuItem.ToolTipText = "Funcionários"
        '
        'ToolStripSeparator2
        '
        Me.ToolStripSeparator2.Name = "ToolStripSeparator2"
        Me.ToolStripSeparator2.Size = New System.Drawing.Size(131, 6)
        '
        'LivrosToolStripMenuItem1
        '
        Me.LivrosToolStripMenuItem1.Image = CType(resources.GetObject("LivrosToolStripMenuItem1.Image"), System.Drawing.Image)
        Me.LivrosToolStripMenuItem1.Name = "LivrosToolStripMenuItem1"
        Me.LivrosToolStripMenuItem1.Size = New System.Drawing.Size(134, 22)
        Me.LivrosToolStripMenuItem1.Text = "Livros"
        Me.LivrosToolStripMenuItem1.ToolTipText = "Livros"
        '
        'EditoriaToolStripMenuItem
        '
        Me.EditoriaToolStripMenuItem.Image = CType(resources.GetObject("EditoriaToolStripMenuItem.Image"), System.Drawing.Image)
        Me.EditoriaToolStripMenuItem.Name = "EditoriaToolStripMenuItem"
        Me.EditoriaToolStripMenuItem.Size = New System.Drawing.Size(134, 22)
        Me.EditoriaToolStripMenuItem.Text = "Editora"
        Me.EditoriaToolStripMenuItem.ToolTipText = "Editora"
        '
        'ProjetosToolStripMenuItem1
        '
        Me.ProjetosToolStripMenuItem1.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.TabelaPeriódicaToolStripMenuItem1, Me.TabelaDeÂnionsECátionsToolStripMenuItem, Me.ToolStripSeparator8, Me.LivrosToolStripMenuItem2, Me.EditoraToolStripMenuItem})
        Me.ProjetosToolStripMenuItem1.Image = CType(resources.GetObject("ProjetosToolStripMenuItem1.Image"), System.Drawing.Image)
        Me.ProjetosToolStripMenuItem1.Name = "ProjetosToolStripMenuItem1"
        Me.ProjetosToolStripMenuItem1.Size = New System.Drawing.Size(133, 22)
        Me.ProjetosToolStripMenuItem1.Text = "Consulta"
        Me.ProjetosToolStripMenuItem1.ToolTipText = "Consulta"
        '
        'TabelaPeriódicaToolStripMenuItem1
        '
        Me.TabelaPeriódicaToolStripMenuItem1.Image = CType(resources.GetObject("TabelaPeriódicaToolStripMenuItem1.Image"), System.Drawing.Image)
        Me.TabelaPeriódicaToolStripMenuItem1.Name = "TabelaPeriódicaToolStripMenuItem1"
        Me.TabelaPeriódicaToolStripMenuItem1.Size = New System.Drawing.Size(134, 22)
        Me.TabelaPeriódicaToolStripMenuItem1.Text = "Locatários"
        Me.TabelaPeriódicaToolStripMenuItem1.ToolTipText = "Locatários"
        '
        'TabelaDeÂnionsECátionsToolStripMenuItem
        '
        Me.TabelaDeÂnionsECátionsToolStripMenuItem.Image = CType(resources.GetObject("TabelaDeÂnionsECátionsToolStripMenuItem.Image"), System.Drawing.Image)
        Me.TabelaDeÂnionsECátionsToolStripMenuItem.Name = "TabelaDeÂnionsECátionsToolStripMenuItem"
        Me.TabelaDeÂnionsECátionsToolStripMenuItem.Size = New System.Drawing.Size(134, 22)
        Me.TabelaDeÂnionsECátionsToolStripMenuItem.Text = "Funcionários"
        Me.TabelaDeÂnionsECátionsToolStripMenuItem.ToolTipText = "Funcionários"
        '
        'ToolStripSeparator8
        '
        Me.ToolStripSeparator8.Name = "ToolStripSeparator8"
        Me.ToolStripSeparator8.Size = New System.Drawing.Size(131, 6)
        '
        'LivrosToolStripMenuItem2
        '
        Me.LivrosToolStripMenuItem2.Image = CType(resources.GetObject("LivrosToolStripMenuItem2.Image"), System.Drawing.Image)
        Me.LivrosToolStripMenuItem2.Name = "LivrosToolStripMenuItem2"
        Me.LivrosToolStripMenuItem2.Size = New System.Drawing.Size(134, 22)
        Me.LivrosToolStripMenuItem2.Text = "Livros"
        Me.LivrosToolStripMenuItem2.ToolTipText = "Livros"
        '
        'EditoraToolStripMenuItem
        '
        Me.EditoraToolStripMenuItem.Image = CType(resources.GetObject("EditoraToolStripMenuItem.Image"), System.Drawing.Image)
        Me.EditoraToolStripMenuItem.Name = "EditoraToolStripMenuItem"
        Me.EditoraToolStripMenuItem.Size = New System.Drawing.Size(134, 22)
        Me.EditoraToolStripMenuItem.Text = "Editora"
        Me.EditoraToolStripMenuItem.ToolTipText = "Editora"
        '
        'FerramentasÚteisToolStripMenuItem
        '
        Me.FerramentasÚteisToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.CalendárioToolStripMenuItem1, Me.CalculadoraToolStripMenuItem})
        Me.FerramentasÚteisToolStripMenuItem.Image = CType(resources.GetObject("FerramentasÚteisToolStripMenuItem.Image"), System.Drawing.Image)
        Me.FerramentasÚteisToolStripMenuItem.Name = "FerramentasÚteisToolStripMenuItem"
        Me.FerramentasÚteisToolStripMenuItem.Size = New System.Drawing.Size(133, 22)
        Me.FerramentasÚteisToolStripMenuItem.Text = "Manutenção"
        Me.FerramentasÚteisToolStripMenuItem.ToolTipText = "Manutenção"
        '
        'CalendárioToolStripMenuItem1
        '
        Me.CalendárioToolStripMenuItem1.Image = CType(resources.GetObject("CalendárioToolStripMenuItem1.Image"), System.Drawing.Image)
        Me.CalendárioToolStripMenuItem1.Name = "CalendárioToolStripMenuItem1"
        Me.CalendárioToolStripMenuItem1.Size = New System.Drawing.Size(124, 22)
        Me.CalendárioToolStripMenuItem1.Text = "Locação"
        Me.CalendárioToolStripMenuItem1.ToolTipText = "Locação"
        '
        'CalculadoraToolStripMenuItem
        '
        Me.CalculadoraToolStripMenuItem.Image = CType(resources.GetObject("CalculadoraToolStripMenuItem.Image"), System.Drawing.Image)
        Me.CalculadoraToolStripMenuItem.Name = "CalculadoraToolStripMenuItem"
        Me.CalculadoraToolStripMenuItem.Size = New System.Drawing.Size(124, 22)
        Me.CalculadoraToolStripMenuItem.Text = "Devolução"
        Me.CalculadoraToolStripMenuItem.ToolTipText = "Devolução"
        '
        'SobreToolStripMenuItem1
        '
        Me.SobreToolStripMenuItem1.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AQuímicaToolStripMenuItem, Me.OProjetoToolStripMenuItem, Me.ODesenvolvedorToolStripMenuItem, Me.ContatoToolStripMenuItem2})
        Me.SobreToolStripMenuItem1.Image = CType(resources.GetObject("SobreToolStripMenuItem1.Image"), System.Drawing.Image)
        Me.SobreToolStripMenuItem1.Name = "SobreToolStripMenuItem1"
        Me.SobreToolStripMenuItem1.Size = New System.Drawing.Size(133, 22)
        Me.SobreToolStripMenuItem1.Text = "Sobre"
        Me.SobreToolStripMenuItem1.ToolTipText = "Sobre"
        '
        'AQuímicaToolStripMenuItem
        '
        Me.AQuímicaToolStripMenuItem.Image = CType(resources.GetObject("AQuímicaToolStripMenuItem.Image"), System.Drawing.Image)
        Me.AQuímicaToolStripMenuItem.Name = "AQuímicaToolStripMenuItem"
        Me.AQuímicaToolStripMenuItem.Size = New System.Drawing.Size(157, 22)
        Me.AQuímicaToolStripMenuItem.Text = "A Química"
        Me.AQuímicaToolStripMenuItem.ToolTipText = "A Química"
        '
        'OProjetoToolStripMenuItem
        '
        Me.OProjetoToolStripMenuItem.Image = CType(resources.GetObject("OProjetoToolStripMenuItem.Image"), System.Drawing.Image)
        Me.OProjetoToolStripMenuItem.Name = "OProjetoToolStripMenuItem"
        Me.OProjetoToolStripMenuItem.Size = New System.Drawing.Size(157, 22)
        Me.OProjetoToolStripMenuItem.Text = "A Proposta"
        Me.OProjetoToolStripMenuItem.ToolTipText = "A Proposta"
        '
        'ODesenvolvedorToolStripMenuItem
        '
        Me.ODesenvolvedorToolStripMenuItem.Image = CType(resources.GetObject("ODesenvolvedorToolStripMenuItem.Image"), System.Drawing.Image)
        Me.ODesenvolvedorToolStripMenuItem.Name = "ODesenvolvedorToolStripMenuItem"
        Me.ODesenvolvedorToolStripMenuItem.Size = New System.Drawing.Size(157, 22)
        Me.ODesenvolvedorToolStripMenuItem.Text = "O Desenvolvedor"
        Me.ODesenvolvedorToolStripMenuItem.ToolTipText = "Desenvolvedor"
        '
        'ContatoToolStripMenuItem2
        '
        Me.ContatoToolStripMenuItem2.Image = CType(resources.GetObject("ContatoToolStripMenuItem2.Image"), System.Drawing.Image)
        Me.ContatoToolStripMenuItem2.Name = "ContatoToolStripMenuItem2"
        Me.ContatoToolStripMenuItem2.Size = New System.Drawing.Size(157, 22)
        Me.ContatoToolStripMenuItem2.Text = "Contato"
        Me.ContatoToolStripMenuItem2.ToolTipText = "Contato"
        '
        'ContatoToolStripMenuItem1
        '
        Me.ContatoToolStripMenuItem1.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.SairToolStripMenuItem1})
        Me.ContatoToolStripMenuItem1.Image = CType(resources.GetObject("ContatoToolStripMenuItem1.Image"), System.Drawing.Image)
        Me.ContatoToolStripMenuItem1.Name = "ContatoToolStripMenuItem1"
        Me.ContatoToolStripMenuItem1.Size = New System.Drawing.Size(133, 22)
        Me.ContatoToolStripMenuItem1.Text = "Arquivo"
        Me.ContatoToolStripMenuItem1.ToolTipText = "Arquivo"
        '
        'SairToolStripMenuItem1
        '
        Me.SairToolStripMenuItem1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.SairToolStripMenuItem1.Image = CType(resources.GetObject("SairToolStripMenuItem1.Image"), System.Drawing.Image)
        Me.SairToolStripMenuItem1.Name = "SairToolStripMenuItem1"
        Me.SairToolStripMenuItem1.Size = New System.Drawing.Size(92, 22)
        Me.SairToolStripMenuItem1.Text = "Sair"
        Me.SairToolStripMenuItem1.ToolTipText = "Sair"
        '
        'StatusStrip1
        '
        Me.StatusStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripStatusLabel2, Me.ToolStripStatusLabel1, Me.ToolStripStatusLabel3})
        Me.StatusStrip1.Location = New System.Drawing.Point(0, 467)
        Me.StatusStrip1.Name = "StatusStrip1"
        Me.StatusStrip1.Size = New System.Drawing.Size(784, 28)
        Me.StatusStrip1.TabIndex = 2
        Me.StatusStrip1.Text = "StatusStrip1"
        '
        'ToolStripStatusLabel2
        '
        Me.ToolStripStatusLabel2.AutoSize = False
        Me.ToolStripStatusLabel2.Font = New System.Drawing.Font("Times New Roman", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ToolStripStatusLabel2.Name = "ToolStripStatusLabel2"
        Me.ToolStripStatusLabel2.Size = New System.Drawing.Size(300, 23)
        Me.ToolStripStatusLabel2.Text = "Bem-Vindos ao sistema de Química"
        '
        'ToolStripStatusLabel1
        '
        Me.ToolStripStatusLabel1.AutoSize = False
        Me.ToolStripStatusLabel1.Font = New System.Drawing.Font("Times New Roman", 15.75!)
        Me.ToolStripStatusLabel1.Name = "ToolStripStatusLabel1"
        Me.ToolStripStatusLabel1.Size = New System.Drawing.Size(300, 23)
        Me.ToolStripStatusLabel1.Text = "ToolStripStatusLabel1"
        '
        'ToolStripStatusLabel3
        '
        Me.ToolStripStatusLabel3.AutoSize = False
        Me.ToolStripStatusLabel3.Font = New System.Drawing.Font("Times New Roman", 15.75!)
        Me.ToolStripStatusLabel3.Name = "ToolStripStatusLabel3"
        Me.ToolStripStatusLabel3.Size = New System.Drawing.Size(300, 23)
        Me.ToolStripStatusLabel3.Text = "ToolStripStatusLabel3"
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.CadastroToolStripMenuItem, Me.ConsultaToolStripMenuItem, Me.ManutencaoToolStripMenuItem, Me.SobreToolStripMenuItem, Me.ArquivoToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(784, 39)
        Me.MenuStrip1.TabIndex = 3
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'CadastroToolStripMenuItem
        '
        Me.CadastroToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.LocatarioToolStripMenuItem, Me.FuncionarioToolStripMenuItem, Me.ToolStripSeparator9, Me.LivrosToolStripMenuItem, Me.EditorasToolStripMenuItem})
        Me.CadastroToolStripMenuItem.Font = New System.Drawing.Font("Times New Roman", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CadastroToolStripMenuItem.Image = CType(resources.GetObject("CadastroToolStripMenuItem.Image"), System.Drawing.Image)
        Me.CadastroToolStripMenuItem.Name = "CadastroToolStripMenuItem"
        Me.CadastroToolStripMenuItem.Size = New System.Drawing.Size(112, 35)
        Me.CadastroToolStripMenuItem.Text = "Cadastro"
        '
        'LocatarioToolStripMenuItem
        '
        Me.LocatarioToolStripMenuItem.Image = CType(resources.GetObject("LocatarioToolStripMenuItem.Image"), System.Drawing.Image)
        Me.LocatarioToolStripMenuItem.Name = "LocatarioToolStripMenuItem"
        Me.LocatarioToolStripMenuItem.Size = New System.Drawing.Size(190, 28)
        Me.LocatarioToolStripMenuItem.Text = "Locatários"
        Me.LocatarioToolStripMenuItem.ToolTipText = "Locatários"
        '
        'FuncionarioToolStripMenuItem
        '
        Me.FuncionarioToolStripMenuItem.Image = CType(resources.GetObject("FuncionarioToolStripMenuItem.Image"), System.Drawing.Image)
        Me.FuncionarioToolStripMenuItem.Name = "FuncionarioToolStripMenuItem"
        Me.FuncionarioToolStripMenuItem.Size = New System.Drawing.Size(190, 28)
        Me.FuncionarioToolStripMenuItem.Text = "Funcionários"
        Me.FuncionarioToolStripMenuItem.ToolTipText = "Funcionários"
        '
        'ToolStripSeparator9
        '
        Me.ToolStripSeparator9.Name = "ToolStripSeparator9"
        Me.ToolStripSeparator9.Size = New System.Drawing.Size(187, 6)
        '
        'LivrosToolStripMenuItem
        '
        Me.LivrosToolStripMenuItem.Image = CType(resources.GetObject("LivrosToolStripMenuItem.Image"), System.Drawing.Image)
        Me.LivrosToolStripMenuItem.Name = "LivrosToolStripMenuItem"
        Me.LivrosToolStripMenuItem.Size = New System.Drawing.Size(190, 28)
        Me.LivrosToolStripMenuItem.Text = "Livros"
        Me.LivrosToolStripMenuItem.ToolTipText = "Livros"
        '
        'EditorasToolStripMenuItem
        '
        Me.EditorasToolStripMenuItem.Image = CType(resources.GetObject("EditorasToolStripMenuItem.Image"), System.Drawing.Image)
        Me.EditorasToolStripMenuItem.Name = "EditorasToolStripMenuItem"
        Me.EditorasToolStripMenuItem.Size = New System.Drawing.Size(190, 28)
        Me.EditorasToolStripMenuItem.Text = "Editoras"
        Me.EditorasToolStripMenuItem.ToolTipText = "Editoras"
        '
        'ConsultaToolStripMenuItem
        '
        Me.ConsultaToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.LocatariosToolStripMenuItem, Me.FuncionariosToolStripMenuItem, Me.ToolStripSeparator1, Me.LivroToolStripMenuItem, Me.WordToolStripMenuItem})
        Me.ConsultaToolStripMenuItem.Font = New System.Drawing.Font("Times New Roman", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ConsultaToolStripMenuItem.Image = CType(resources.GetObject("ConsultaToolStripMenuItem.Image"), System.Drawing.Image)
        Me.ConsultaToolStripMenuItem.Name = "ConsultaToolStripMenuItem"
        Me.ConsultaToolStripMenuItem.Size = New System.Drawing.Size(113, 35)
        Me.ConsultaToolStripMenuItem.Text = "Consulta"
        '
        'LocatariosToolStripMenuItem
        '
        Me.LocatariosToolStripMenuItem.Image = CType(resources.GetObject("LocatariosToolStripMenuItem.Image"), System.Drawing.Image)
        Me.LocatariosToolStripMenuItem.Name = "LocatariosToolStripMenuItem"
        Me.LocatariosToolStripMenuItem.Size = New System.Drawing.Size(190, 28)
        Me.LocatariosToolStripMenuItem.Text = "Locatários"
        Me.LocatariosToolStripMenuItem.ToolTipText = "Locatários"
        '
        'FuncionariosToolStripMenuItem
        '
        Me.FuncionariosToolStripMenuItem.Image = CType(resources.GetObject("FuncionariosToolStripMenuItem.Image"), System.Drawing.Image)
        Me.FuncionariosToolStripMenuItem.Name = "FuncionariosToolStripMenuItem"
        Me.FuncionariosToolStripMenuItem.Size = New System.Drawing.Size(190, 28)
        Me.FuncionariosToolStripMenuItem.Text = "Funcionários"
        Me.FuncionariosToolStripMenuItem.ToolTipText = "Funcionários"
        '
        'ToolStripSeparator1
        '
        Me.ToolStripSeparator1.Name = "ToolStripSeparator1"
        Me.ToolStripSeparator1.Size = New System.Drawing.Size(187, 6)
        '
        'LivroToolStripMenuItem
        '
        Me.LivroToolStripMenuItem.Image = CType(resources.GetObject("LivroToolStripMenuItem.Image"), System.Drawing.Image)
        Me.LivroToolStripMenuItem.Name = "LivroToolStripMenuItem"
        Me.LivroToolStripMenuItem.Size = New System.Drawing.Size(190, 28)
        Me.LivroToolStripMenuItem.Text = "Livros"
        Me.LivroToolStripMenuItem.ToolTipText = "Livros "
        '
        'WordToolStripMenuItem
        '
        Me.WordToolStripMenuItem.Image = CType(resources.GetObject("WordToolStripMenuItem.Image"), System.Drawing.Image)
        Me.WordToolStripMenuItem.Name = "WordToolStripMenuItem"
        Me.WordToolStripMenuItem.Size = New System.Drawing.Size(190, 28)
        Me.WordToolStripMenuItem.Text = "Editoras"
        Me.WordToolStripMenuItem.ToolTipText = "Editoras"
        '
        'ManutencaoToolStripMenuItem
        '
        Me.ManutencaoToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.LocacaoToolStripMenuItem, Me.DevolucaoToolStripMenuItem})
        Me.ManutencaoToolStripMenuItem.Font = New System.Drawing.Font("Times New Roman", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ManutencaoToolStripMenuItem.Image = CType(resources.GetObject("ManutencaoToolStripMenuItem.Image"), System.Drawing.Image)
        Me.ManutencaoToolStripMenuItem.Name = "ManutencaoToolStripMenuItem"
        Me.ManutencaoToolStripMenuItem.Size = New System.Drawing.Size(140, 35)
        Me.ManutencaoToolStripMenuItem.Text = "Manutenção"
        '
        'LocacaoToolStripMenuItem
        '
        Me.LocacaoToolStripMenuItem.Image = CType(resources.GetObject("LocacaoToolStripMenuItem.Image"), System.Drawing.Image)
        Me.LocacaoToolStripMenuItem.Name = "LocacaoToolStripMenuItem"
        Me.LocacaoToolStripMenuItem.Size = New System.Drawing.Size(171, 28)
        Me.LocacaoToolStripMenuItem.Text = "Locação"
        Me.LocacaoToolStripMenuItem.ToolTipText = "Locação"
        '
        'DevolucaoToolStripMenuItem
        '
        Me.DevolucaoToolStripMenuItem.Image = CType(resources.GetObject("DevolucaoToolStripMenuItem.Image"), System.Drawing.Image)
        Me.DevolucaoToolStripMenuItem.Name = "DevolucaoToolStripMenuItem"
        Me.DevolucaoToolStripMenuItem.Size = New System.Drawing.Size(171, 28)
        Me.DevolucaoToolStripMenuItem.Text = "Devolução"
        Me.DevolucaoToolStripMenuItem.ToolTipText = "Devolução"
        '
        'SobreToolStripMenuItem
        '
        Me.SobreToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.QuímicaToolStripMenuItem, Me.PropostaToolStripMenuItem, Me.DesenvolvedorToolStripMenuItem, Me.ContatoToolStripMenuItem})
        Me.SobreToolStripMenuItem.Font = New System.Drawing.Font("Times New Roman", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.SobreToolStripMenuItem.Image = CType(resources.GetObject("SobreToolStripMenuItem.Image"), System.Drawing.Image)
        Me.SobreToolStripMenuItem.Name = "SobreToolStripMenuItem"
        Me.SobreToolStripMenuItem.Size = New System.Drawing.Size(86, 35)
        Me.SobreToolStripMenuItem.Text = "Sobre"
        '
        'QuímicaToolStripMenuItem
        '
        Me.QuímicaToolStripMenuItem.Image = CType(resources.GetObject("QuímicaToolStripMenuItem.Image"), System.Drawing.Image)
        Me.QuímicaToolStripMenuItem.Name = "QuímicaToolStripMenuItem"
        Me.QuímicaToolStripMenuItem.Size = New System.Drawing.Size(225, 28)
        Me.QuímicaToolStripMenuItem.Text = "A Química"
        Me.QuímicaToolStripMenuItem.ToolTipText = "A Química"
        '
        'PropostaToolStripMenuItem
        '
        Me.PropostaToolStripMenuItem.Image = CType(resources.GetObject("PropostaToolStripMenuItem.Image"), System.Drawing.Image)
        Me.PropostaToolStripMenuItem.Name = "PropostaToolStripMenuItem"
        Me.PropostaToolStripMenuItem.Size = New System.Drawing.Size(225, 28)
        Me.PropostaToolStripMenuItem.Text = "A Proposta"
        Me.PropostaToolStripMenuItem.ToolTipText = "A Proposta"
        '
        'DesenvolvedorToolStripMenuItem
        '
        Me.DesenvolvedorToolStripMenuItem.Image = CType(resources.GetObject("DesenvolvedorToolStripMenuItem.Image"), System.Drawing.Image)
        Me.DesenvolvedorToolStripMenuItem.Name = "DesenvolvedorToolStripMenuItem"
        Me.DesenvolvedorToolStripMenuItem.Size = New System.Drawing.Size(225, 28)
        Me.DesenvolvedorToolStripMenuItem.Text = "O Desenvolvedor"
        Me.DesenvolvedorToolStripMenuItem.ToolTipText = "O Desenvolvedor"
        '
        'ContatoToolStripMenuItem
        '
        Me.ContatoToolStripMenuItem.Image = CType(resources.GetObject("ContatoToolStripMenuItem.Image"), System.Drawing.Image)
        Me.ContatoToolStripMenuItem.Name = "ContatoToolStripMenuItem"
        Me.ContatoToolStripMenuItem.Size = New System.Drawing.Size(225, 28)
        Me.ContatoToolStripMenuItem.Text = "Contato"
        Me.ContatoToolStripMenuItem.ToolTipText = "Contato"
        '
        'ArquivoToolStripMenuItem
        '
        Me.ArquivoToolStripMenuItem.AutoSize = False
        Me.ArquivoToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.SairToolStripMenuItem})
        Me.ArquivoToolStripMenuItem.Font = New System.Drawing.Font("Times New Roman", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ArquivoToolStripMenuItem.Image = CType(resources.GetObject("ArquivoToolStripMenuItem.Image"), System.Drawing.Image)
        Me.ArquivoToolStripMenuItem.Name = "ArquivoToolStripMenuItem"
        Me.ArquivoToolStripMenuItem.Size = New System.Drawing.Size(94, 35)
        Me.ArquivoToolStripMenuItem.Text = "Arquivo"
        '
        'SairToolStripMenuItem
        '
        Me.SairToolStripMenuItem.Image = CType(resources.GetObject("SairToolStripMenuItem.Image"), System.Drawing.Image)
        Me.SairToolStripMenuItem.Name = "SairToolStripMenuItem"
        Me.SairToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.S), System.Windows.Forms.Keys)
        Me.SairToolStripMenuItem.Size = New System.Drawing.Size(179, 28)
        Me.SairToolStripMenuItem.Text = "Sair"
        Me.SairToolStripMenuItem.ToolTipText = "Sair"
        '
        'Timer1
        '
        Me.Timer1.Enabled = True
        '
        'ToolStrip1
        '
        Me.ToolStrip1.ImageScalingSize = New System.Drawing.Size(64, 64)
        Me.ToolStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripButton2, Me.ToolStripButton4, Me.ToolStripButton13, Me.ToolStripSeparator3, Me.ToolStripButton3, Me.ToolStripButton12, Me.ToolStripSeparator5, Me.ToolStripButton1, Me.ToolStripButton11, Me.ToolStripSeparator4, Me.ToolStripButton8, Me.ToolStripSeparator7})
        Me.ToolStrip1.Location = New System.Drawing.Point(0, 39)
        Me.ToolStrip1.Name = "ToolStrip1"
        Me.ToolStrip1.Size = New System.Drawing.Size(784, 71)
        Me.ToolStrip1.TabIndex = 4
        Me.ToolStrip1.Text = "ToolStrip1"
        '
        'ToolStripButton2
        '
        Me.ToolStripButton2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ToolStripButton2.Image = CType(resources.GetObject("ToolStripButton2.Image"), System.Drawing.Image)
        Me.ToolStripButton2.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton2.Name = "ToolStripButton2"
        Me.ToolStripButton2.Size = New System.Drawing.Size(68, 68)
        Me.ToolStripButton2.ToolTipText = "Backup"
        '
        'ToolStripButton4
        '
        Me.ToolStripButton4.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ToolStripButton4.Image = CType(resources.GetObject("ToolStripButton4.Image"), System.Drawing.Image)
        Me.ToolStripButton4.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton4.Name = "ToolStripButton4"
        Me.ToolStripButton4.Size = New System.Drawing.Size(68, 68)
        Me.ToolStripButton4.Text = "ToolStripButton4"
        Me.ToolStripButton4.ToolTipText = "Restaura Beckup"
        '
        'ToolStripButton13
        '
        Me.ToolStripButton13.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ToolStripButton13.Image = CType(resources.GetObject("ToolStripButton13.Image"), System.Drawing.Image)
        Me.ToolStripButton13.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton13.Name = "ToolStripButton13"
        Me.ToolStripButton13.Size = New System.Drawing.Size(68, 68)
        Me.ToolStripButton13.Text = "ToolStripButton13"
        Me.ToolStripButton13.ToolTipText = "Relatórios"
        '
        'ToolStripSeparator3
        '
        Me.ToolStripSeparator3.Name = "ToolStripSeparator3"
        Me.ToolStripSeparator3.Size = New System.Drawing.Size(6, 71)
        '
        'ToolStripButton3
        '
        Me.ToolStripButton3.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ToolStripButton3.Image = CType(resources.GetObject("ToolStripButton3.Image"), System.Drawing.Image)
        Me.ToolStripButton3.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton3.Name = "ToolStripButton3"
        Me.ToolStripButton3.Size = New System.Drawing.Size(68, 68)
        Me.ToolStripButton3.Text = "ToolStripButton3"
        Me.ToolStripButton3.ToolTipText = "Cadastro de Funcionários"
        '
        'ToolStripButton12
        '
        Me.ToolStripButton12.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ToolStripButton12.Image = CType(resources.GetObject("ToolStripButton12.Image"), System.Drawing.Image)
        Me.ToolStripButton12.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton12.Name = "ToolStripButton12"
        Me.ToolStripButton12.Size = New System.Drawing.Size(68, 68)
        Me.ToolStripButton12.Text = "ToolStripButton12"
        Me.ToolStripButton12.ToolTipText = "Cadastro de Locatários"
        '
        'ToolStripSeparator5
        '
        Me.ToolStripSeparator5.Name = "ToolStripSeparator5"
        Me.ToolStripSeparator5.Size = New System.Drawing.Size(6, 71)
        '
        'ToolStripButton1
        '
        Me.ToolStripButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ToolStripButton1.Image = CType(resources.GetObject("ToolStripButton1.Image"), System.Drawing.Image)
        Me.ToolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton1.Name = "ToolStripButton1"
        Me.ToolStripButton1.Size = New System.Drawing.Size(68, 68)
        Me.ToolStripButton1.Text = "ToolStripButton1"
        Me.ToolStripButton1.ToolTipText = "Locação de Livros"
        '
        'ToolStripButton11
        '
        Me.ToolStripButton11.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ToolStripButton11.Image = CType(resources.GetObject("ToolStripButton11.Image"), System.Drawing.Image)
        Me.ToolStripButton11.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton11.Name = "ToolStripButton11"
        Me.ToolStripButton11.Size = New System.Drawing.Size(68, 68)
        Me.ToolStripButton11.Text = "Cadastros-Editora"
        Me.ToolStripButton11.ToolTipText = "Devolução dos Livros"
        '
        'ToolStripSeparator4
        '
        Me.ToolStripSeparator4.Name = "ToolStripSeparator4"
        Me.ToolStripSeparator4.Size = New System.Drawing.Size(6, 71)
        '
        'ToolStripButton8
        '
        Me.ToolStripButton8.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ToolStripButton8.Image = CType(resources.GetObject("ToolStripButton8.Image"), System.Drawing.Image)
        Me.ToolStripButton8.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton8.Name = "ToolStripButton8"
        Me.ToolStripButton8.Size = New System.Drawing.Size(68, 68)
        Me.ToolStripButton8.Text = "ToolStripButton8"
        Me.ToolStripButton8.ToolTipText = "Configuração"
        '
        'ToolStripSeparator7
        '
        Me.ToolStripSeparator7.Name = "ToolStripSeparator7"
        Me.ToolStripSeparator7.Size = New System.Drawing.Size(6, 71)
        '
        'ToolStripSeparator6
        '
        Me.ToolStripSeparator6.Name = "ToolStripSeparator6"
        Me.ToolStripSeparator6.Size = New System.Drawing.Size(6, 6)
        '
        'FrmPrin
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(784, 495)
        Me.ContextMenuStrip = Me.ContextMenuStrip1
        Me.Controls.Add(Me.ToolStrip1)
        Me.Controls.Add(Me.StatusStrip1)
        Me.Controls.Add(Me.MenuStrip1)
        Me.DoubleBuffered = True
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "FrmPrin"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Página Principal "
        Me.ContextMenuStrip1.ResumeLayout(False)
        Me.StatusStrip1.ResumeLayout(False)
        Me.StatusStrip1.PerformLayout()
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ToolStrip1.ResumeLayout(False)
        Me.ToolStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents ContextMenuStrip1 As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents StatusStrip1 As System.Windows.Forms.StatusStrip
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents ArquivoToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SairToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ConsultaToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripStatusLabel1 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents ToolStripStatusLabel2 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents CadastroToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents LocatarioToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents FuncionarioToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SobreToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents QuímicaToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PropostaToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DesenvolvedorToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents LocatariosToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents FuncionariosToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents LivroToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents WordToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ManutencaoToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripStatusLabel3 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents ToolTip1 As System.Windows.Forms.ToolTip
    Friend WithEvents CadastroToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents LocatariosToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ProjetosToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TabelaPeriódicaToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents FerramentasÚteisToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CalendárioToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CalculadoraToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SobreToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AQuímicaToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents OProjetoToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ODesenvolvedorToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ContatoToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TabelaDeÂnionsECátionsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator9 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents LivrosToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents EditorasToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents LocacaoToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DevolucaoToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStrip1 As System.Windows.Forms.ToolStrip
    Friend WithEvents ToolStripButton2 As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripButton1 As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripButton3 As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripButton4 As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripSeparator3 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ToolStripSeparator4 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ToolStripButton8 As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripButton11 As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripSeparator5 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ToolStripButton12 As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripButton13 As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripSeparator7 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ToolStripSeparator6 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents FuncionáriosToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents LivrosToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents EditoriaToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator8 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents LivrosToolStripMenuItem2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents EditoraToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SairToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ContatoToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ContatoToolStripMenuItem2 As System.Windows.Forms.ToolStripMenuItem
End Class
