﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmPrin
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FrmPrin))
        Me.ToolStrip1 = New System.Windows.Forms.ToolStrip
        Me.ToolStripButton1 = New System.Windows.Forms.ToolStripButton
        Me.ToolStripSeparator3 = New System.Windows.Forms.ToolStripSeparator
        Me.ToolStripButton2 = New System.Windows.Forms.ToolStripButton
        Me.ToolStripButton3 = New System.Windows.Forms.ToolStripButton
        Me.ToolStripSeparator4 = New System.Windows.Forms.ToolStripSeparator
        Me.ToolStripButton4 = New System.Windows.Forms.ToolStripButton
        Me.ToolStripButton5 = New System.Windows.Forms.ToolStripButton
        Me.ToolStripSeparator5 = New System.Windows.Forms.ToolStripSeparator
        Me.ToolStripButton6 = New System.Windows.Forms.ToolStripButton
        Me.ToolStripButton7 = New System.Windows.Forms.ToolStripButton
        Me.ToolStripButton8 = New System.Windows.Forms.ToolStripButton
        Me.ToolStripSeparator6 = New System.Windows.Forms.ToolStripSeparator
        Me.ToolStripButton9 = New System.Windows.Forms.ToolStripButton
        Me.ToolStripButton10 = New System.Windows.Forms.ToolStripButton
        Me.ToolStripButton11 = New System.Windows.Forms.ToolStripButton
        Me.ToolStripSeparator7 = New System.Windows.Forms.ToolStripSeparator
        Me.ToolStripButton12 = New System.Windows.Forms.ToolStripButton
        Me.ToolStripButton13 = New System.Windows.Forms.ToolStripButton
        Me.ToolStripButton14 = New System.Windows.Forms.ToolStripButton
        Me.ToolStripSeparator8 = New System.Windows.Forms.ToolStripSeparator
        Me.ToolStripButton15 = New System.Windows.Forms.ToolStripButton
        Me.ContextMenuStrip1 = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.ArquivoToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem
        Me.SairToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem
        Me.ProjetosToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem
        Me.TabelaPeriódicaToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem
        Me.TabelaDeÂnionsECátionsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.FerramentasÚteisToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.CalendárioToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem
        Me.CalculadoraToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.NotepadToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem
        Me.WordToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem
        Me.ExcelToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem
        Me.ExploToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ChromeToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem
        Me.YoutubeToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem
        Me.SobreToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem
        Me.AQuímicaToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.OProjetoToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ODesenvolvedorToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ContatoToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem
        Me.StatusStrip1 = New System.Windows.Forms.StatusStrip
        Me.ToolStripStatusLabel1 = New System.Windows.Forms.ToolStripStatusLabel
        Me.ToolStripStatusLabel2 = New System.Windows.Forms.ToolStripStatusLabel
        Me.ToolStripStatusLabel3 = New System.Windows.Forms.ToolStripStatusLabel
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip
        Me.ArquivoToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.SairToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ProjetosToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.TabelaPeriódicaToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.TabelaDeÂnionsECâtionsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.SobreAQuímicaToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.CalendárioToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.CálculadoraToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator
        Me.NotePadToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.WordToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ExcelToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripSeparator2 = New System.Windows.Forms.ToolStripSeparator
        Me.ExplorerToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ChromeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.YoutubeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.SobreToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.QuímicaToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.PropostaToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.DesenvolvedorToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ContatoToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.ToolStrip1.SuspendLayout()
        Me.ContextMenuStrip1.SuspendLayout()
        Me.StatusStrip1.SuspendLayout()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'ToolStrip1
        '
        Me.ToolStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripButton1, Me.ToolStripSeparator3, Me.ToolStripButton2, Me.ToolStripButton3, Me.ToolStripSeparator4, Me.ToolStripButton4, Me.ToolStripButton5, Me.ToolStripSeparator5, Me.ToolStripButton6, Me.ToolStripButton7, Me.ToolStripButton8, Me.ToolStripSeparator6, Me.ToolStripButton9, Me.ToolStripButton10, Me.ToolStripButton11, Me.ToolStripSeparator7, Me.ToolStripButton12, Me.ToolStripButton13, Me.ToolStripButton14, Me.ToolStripSeparator8, Me.ToolStripButton15})
        Me.ToolStrip1.Location = New System.Drawing.Point(0, 29)
        Me.ToolStrip1.Name = "ToolStrip1"
        Me.ToolStrip1.Size = New System.Drawing.Size(866, 25)
        Me.ToolStrip1.TabIndex = 0
        Me.ToolStrip1.Text = "ToolStrip1"
        '
        'ToolStripButton1
        '
        Me.ToolStripButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ToolStripButton1.Image = CType(resources.GetObject("ToolStripButton1.Image"), System.Drawing.Image)
        Me.ToolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton1.Name = "ToolStripButton1"
        Me.ToolStripButton1.Size = New System.Drawing.Size(23, 22)
        Me.ToolStripButton1.Text = "ToolStripButton1"
        Me.ToolStripButton1.ToolTipText = "Sair"
        '
        'ToolStripSeparator3
        '
        Me.ToolStripSeparator3.Name = "ToolStripSeparator3"
        Me.ToolStripSeparator3.Size = New System.Drawing.Size(6, 25)
        '
        'ToolStripButton2
        '
        Me.ToolStripButton2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ToolStripButton2.Image = CType(resources.GetObject("ToolStripButton2.Image"), System.Drawing.Image)
        Me.ToolStripButton2.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton2.Name = "ToolStripButton2"
        Me.ToolStripButton2.Size = New System.Drawing.Size(23, 22)
        Me.ToolStripButton2.Text = "ToolStripButton2"
        Me.ToolStripButton2.ToolTipText = "Tabela Periódica"
        '
        'ToolStripButton3
        '
        Me.ToolStripButton3.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ToolStripButton3.Image = CType(resources.GetObject("ToolStripButton3.Image"), System.Drawing.Image)
        Me.ToolStripButton3.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton3.Name = "ToolStripButton3"
        Me.ToolStripButton3.Size = New System.Drawing.Size(23, 22)
        Me.ToolStripButton3.Text = "ToolStripButton3"
        Me.ToolStripButton3.ToolTipText = "Tabela de Ânions e Cátions"
        '
        'ToolStripSeparator4
        '
        Me.ToolStripSeparator4.Name = "ToolStripSeparator4"
        Me.ToolStripSeparator4.Size = New System.Drawing.Size(6, 25)
        '
        'ToolStripButton4
        '
        Me.ToolStripButton4.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ToolStripButton4.Image = CType(resources.GetObject("ToolStripButton4.Image"), System.Drawing.Image)
        Me.ToolStripButton4.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton4.Name = "ToolStripButton4"
        Me.ToolStripButton4.Size = New System.Drawing.Size(23, 22)
        Me.ToolStripButton4.Text = "ToolStripButton4"
        Me.ToolStripButton4.ToolTipText = "Calendário"
        '
        'ToolStripButton5
        '
        Me.ToolStripButton5.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ToolStripButton5.Image = CType(resources.GetObject("ToolStripButton5.Image"), System.Drawing.Image)
        Me.ToolStripButton5.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton5.Name = "ToolStripButton5"
        Me.ToolStripButton5.Size = New System.Drawing.Size(23, 22)
        Me.ToolStripButton5.Text = "ToolStripButton5"
        Me.ToolStripButton5.ToolTipText = "Calculadora"
        '
        'ToolStripSeparator5
        '
        Me.ToolStripSeparator5.Name = "ToolStripSeparator5"
        Me.ToolStripSeparator5.Size = New System.Drawing.Size(6, 25)
        '
        'ToolStripButton6
        '
        Me.ToolStripButton6.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ToolStripButton6.Image = CType(resources.GetObject("ToolStripButton6.Image"), System.Drawing.Image)
        Me.ToolStripButton6.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton6.Name = "ToolStripButton6"
        Me.ToolStripButton6.Size = New System.Drawing.Size(23, 22)
        Me.ToolStripButton6.Text = "ToolStripButton6"
        Me.ToolStripButton6.ToolTipText = "Notepad" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        '
        'ToolStripButton7
        '
        Me.ToolStripButton7.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ToolStripButton7.Image = CType(resources.GetObject("ToolStripButton7.Image"), System.Drawing.Image)
        Me.ToolStripButton7.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton7.Name = "ToolStripButton7"
        Me.ToolStripButton7.Size = New System.Drawing.Size(23, 22)
        Me.ToolStripButton7.Text = "ToolStripButton7"
        Me.ToolStripButton7.ToolTipText = "Word"
        '
        'ToolStripButton8
        '
        Me.ToolStripButton8.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ToolStripButton8.Image = CType(resources.GetObject("ToolStripButton8.Image"), System.Drawing.Image)
        Me.ToolStripButton8.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton8.Name = "ToolStripButton8"
        Me.ToolStripButton8.Size = New System.Drawing.Size(23, 22)
        Me.ToolStripButton8.Text = "ToolStripButton8"
        Me.ToolStripButton8.ToolTipText = "Excel"
        '
        'ToolStripSeparator6
        '
        Me.ToolStripSeparator6.Name = "ToolStripSeparator6"
        Me.ToolStripSeparator6.Size = New System.Drawing.Size(6, 25)
        '
        'ToolStripButton9
        '
        Me.ToolStripButton9.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ToolStripButton9.Image = CType(resources.GetObject("ToolStripButton9.Image"), System.Drawing.Image)
        Me.ToolStripButton9.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton9.Name = "ToolStripButton9"
        Me.ToolStripButton9.Size = New System.Drawing.Size(23, 22)
        Me.ToolStripButton9.Text = "Explorer"
        '
        'ToolStripButton10
        '
        Me.ToolStripButton10.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ToolStripButton10.Image = CType(resources.GetObject("ToolStripButton10.Image"), System.Drawing.Image)
        Me.ToolStripButton10.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton10.Name = "ToolStripButton10"
        Me.ToolStripButton10.Size = New System.Drawing.Size(23, 22)
        Me.ToolStripButton10.Text = "ToolStripButton10"
        Me.ToolStripButton10.ToolTipText = "Chrome"
        '
        'ToolStripButton11
        '
        Me.ToolStripButton11.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ToolStripButton11.Image = CType(resources.GetObject("ToolStripButton11.Image"), System.Drawing.Image)
        Me.ToolStripButton11.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton11.Name = "ToolStripButton11"
        Me.ToolStripButton11.Size = New System.Drawing.Size(23, 22)
        Me.ToolStripButton11.Text = "Youtube"
        '
        'ToolStripSeparator7
        '
        Me.ToolStripSeparator7.Name = "ToolStripSeparator7"
        Me.ToolStripSeparator7.Size = New System.Drawing.Size(6, 25)
        '
        'ToolStripButton12
        '
        Me.ToolStripButton12.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ToolStripButton12.Image = CType(resources.GetObject("ToolStripButton12.Image"), System.Drawing.Image)
        Me.ToolStripButton12.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton12.Name = "ToolStripButton12"
        Me.ToolStripButton12.Size = New System.Drawing.Size(23, 22)
        Me.ToolStripButton12.Text = "Química"
        '
        'ToolStripButton13
        '
        Me.ToolStripButton13.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ToolStripButton13.Image = CType(resources.GetObject("ToolStripButton13.Image"), System.Drawing.Image)
        Me.ToolStripButton13.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton13.Name = "ToolStripButton13"
        Me.ToolStripButton13.Size = New System.Drawing.Size(23, 22)
        Me.ToolStripButton13.Text = "ToolStripButton13"
        Me.ToolStripButton13.ToolTipText = "Proposta"
        '
        'ToolStripButton14
        '
        Me.ToolStripButton14.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ToolStripButton14.Image = CType(resources.GetObject("ToolStripButton14.Image"), System.Drawing.Image)
        Me.ToolStripButton14.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton14.Name = "ToolStripButton14"
        Me.ToolStripButton14.Size = New System.Drawing.Size(23, 22)
        Me.ToolStripButton14.Text = "ToolStripButton14"
        Me.ToolStripButton14.ToolTipText = "Desenvolvedor"
        '
        'ToolStripSeparator8
        '
        Me.ToolStripSeparator8.Name = "ToolStripSeparator8"
        Me.ToolStripSeparator8.Size = New System.Drawing.Size(6, 25)
        '
        'ToolStripButton15
        '
        Me.ToolStripButton15.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ToolStripButton15.Image = CType(resources.GetObject("ToolStripButton15.Image"), System.Drawing.Image)
        Me.ToolStripButton15.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton15.Name = "ToolStripButton15"
        Me.ToolStripButton15.Size = New System.Drawing.Size(23, 22)
        Me.ToolStripButton15.Text = "ToolStripButton15"
        Me.ToolStripButton15.ToolTipText = "Contato"
        '
        'ContextMenuStrip1
        '
        Me.ContextMenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ArquivoToolStripMenuItem1, Me.ProjetosToolStripMenuItem1, Me.FerramentasÚteisToolStripMenuItem, Me.SobreToolStripMenuItem1, Me.ContatoToolStripMenuItem1})
        Me.ContextMenuStrip1.Name = "ContextMenuStrip1"
        Me.ContextMenuStrip1.Size = New System.Drawing.Size(168, 114)
        '
        'ArquivoToolStripMenuItem1
        '
        Me.ArquivoToolStripMenuItem1.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.SairToolStripMenuItem1})
        Me.ArquivoToolStripMenuItem1.Image = CType(resources.GetObject("ArquivoToolStripMenuItem1.Image"), System.Drawing.Image)
        Me.ArquivoToolStripMenuItem1.Name = "ArquivoToolStripMenuItem1"
        Me.ArquivoToolStripMenuItem1.Size = New System.Drawing.Size(167, 22)
        Me.ArquivoToolStripMenuItem1.Text = "Arquivo"
        '
        'SairToolStripMenuItem1
        '
        Me.SairToolStripMenuItem1.Image = CType(resources.GetObject("SairToolStripMenuItem1.Image"), System.Drawing.Image)
        Me.SairToolStripMenuItem1.Name = "SairToolStripMenuItem1"
        Me.SairToolStripMenuItem1.Size = New System.Drawing.Size(93, 22)
        Me.SairToolStripMenuItem1.Text = "Sair"
        '
        'ProjetosToolStripMenuItem1
        '
        Me.ProjetosToolStripMenuItem1.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.TabelaPeriódicaToolStripMenuItem1, Me.TabelaDeÂnionsECátionsToolStripMenuItem})
        Me.ProjetosToolStripMenuItem1.Image = CType(resources.GetObject("ProjetosToolStripMenuItem1.Image"), System.Drawing.Image)
        Me.ProjetosToolStripMenuItem1.Name = "ProjetosToolStripMenuItem1"
        Me.ProjetosToolStripMenuItem1.Size = New System.Drawing.Size(167, 22)
        Me.ProjetosToolStripMenuItem1.Text = "Projetos"
        '
        'TabelaPeriódicaToolStripMenuItem1
        '
        Me.TabelaPeriódicaToolStripMenuItem1.Image = CType(resources.GetObject("TabelaPeriódicaToolStripMenuItem1.Image"), System.Drawing.Image)
        Me.TabelaPeriódicaToolStripMenuItem1.Name = "TabelaPeriódicaToolStripMenuItem1"
        Me.TabelaPeriódicaToolStripMenuItem1.Size = New System.Drawing.Size(216, 22)
        Me.TabelaPeriódicaToolStripMenuItem1.Text = "Tabela Periódica"
        '
        'TabelaDeÂnionsECátionsToolStripMenuItem
        '
        Me.TabelaDeÂnionsECátionsToolStripMenuItem.Image = CType(resources.GetObject("TabelaDeÂnionsECátionsToolStripMenuItem.Image"), System.Drawing.Image)
        Me.TabelaDeÂnionsECátionsToolStripMenuItem.Name = "TabelaDeÂnionsECátionsToolStripMenuItem"
        Me.TabelaDeÂnionsECátionsToolStripMenuItem.Size = New System.Drawing.Size(216, 22)
        Me.TabelaDeÂnionsECátionsToolStripMenuItem.Text = "Tabela de Ânions e Cátions"
        '
        'FerramentasÚteisToolStripMenuItem
        '
        Me.FerramentasÚteisToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.CalendárioToolStripMenuItem1, Me.CalculadoraToolStripMenuItem, Me.NotepadToolStripMenuItem1, Me.WordToolStripMenuItem1, Me.ExcelToolStripMenuItem1, Me.ExploToolStripMenuItem, Me.ChromeToolStripMenuItem1, Me.YoutubeToolStripMenuItem1})
        Me.FerramentasÚteisToolStripMenuItem.Image = CType(resources.GetObject("FerramentasÚteisToolStripMenuItem.Image"), System.Drawing.Image)
        Me.FerramentasÚteisToolStripMenuItem.Name = "FerramentasÚteisToolStripMenuItem"
        Me.FerramentasÚteisToolStripMenuItem.Size = New System.Drawing.Size(167, 22)
        Me.FerramentasÚteisToolStripMenuItem.Text = "Ferramentas úteis"
        '
        'CalendárioToolStripMenuItem1
        '
        Me.CalendárioToolStripMenuItem1.Image = CType(resources.GetObject("CalendárioToolStripMenuItem1.Image"), System.Drawing.Image)
        Me.CalendárioToolStripMenuItem1.Name = "CalendárioToolStripMenuItem1"
        Me.CalendárioToolStripMenuItem1.Size = New System.Drawing.Size(152, 22)
        Me.CalendárioToolStripMenuItem1.Text = "Calendário"
        '
        'CalculadoraToolStripMenuItem
        '
        Me.CalculadoraToolStripMenuItem.Image = CType(resources.GetObject("CalculadoraToolStripMenuItem.Image"), System.Drawing.Image)
        Me.CalculadoraToolStripMenuItem.Name = "CalculadoraToolStripMenuItem"
        Me.CalculadoraToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.CalculadoraToolStripMenuItem.Text = "Calculadora"
        '
        'NotepadToolStripMenuItem1
        '
        Me.NotepadToolStripMenuItem1.Image = CType(resources.GetObject("NotepadToolStripMenuItem1.Image"), System.Drawing.Image)
        Me.NotepadToolStripMenuItem1.Name = "NotepadToolStripMenuItem1"
        Me.NotepadToolStripMenuItem1.Size = New System.Drawing.Size(152, 22)
        Me.NotepadToolStripMenuItem1.Text = "Notepad"
        '
        'WordToolStripMenuItem1
        '
        Me.WordToolStripMenuItem1.Image = CType(resources.GetObject("WordToolStripMenuItem1.Image"), System.Drawing.Image)
        Me.WordToolStripMenuItem1.Name = "WordToolStripMenuItem1"
        Me.WordToolStripMenuItem1.Size = New System.Drawing.Size(152, 22)
        Me.WordToolStripMenuItem1.Text = "Word"
        '
        'ExcelToolStripMenuItem1
        '
        Me.ExcelToolStripMenuItem1.Image = CType(resources.GetObject("ExcelToolStripMenuItem1.Image"), System.Drawing.Image)
        Me.ExcelToolStripMenuItem1.Name = "ExcelToolStripMenuItem1"
        Me.ExcelToolStripMenuItem1.Size = New System.Drawing.Size(152, 22)
        Me.ExcelToolStripMenuItem1.Text = "Excel"
        '
        'ExploToolStripMenuItem
        '
        Me.ExploToolStripMenuItem.Image = CType(resources.GetObject("ExploToolStripMenuItem.Image"), System.Drawing.Image)
        Me.ExploToolStripMenuItem.Name = "ExploToolStripMenuItem"
        Me.ExploToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.ExploToolStripMenuItem.Text = "Explorer"
        '
        'ChromeToolStripMenuItem1
        '
        Me.ChromeToolStripMenuItem1.Image = CType(resources.GetObject("ChromeToolStripMenuItem1.Image"), System.Drawing.Image)
        Me.ChromeToolStripMenuItem1.Name = "ChromeToolStripMenuItem1"
        Me.ChromeToolStripMenuItem1.Size = New System.Drawing.Size(152, 22)
        Me.ChromeToolStripMenuItem1.Text = "Chrome"
        '
        'YoutubeToolStripMenuItem1
        '
        Me.YoutubeToolStripMenuItem1.Image = CType(resources.GetObject("YoutubeToolStripMenuItem1.Image"), System.Drawing.Image)
        Me.YoutubeToolStripMenuItem1.Name = "YoutubeToolStripMenuItem1"
        Me.YoutubeToolStripMenuItem1.Size = New System.Drawing.Size(152, 22)
        Me.YoutubeToolStripMenuItem1.Text = "Youtube"
        '
        'SobreToolStripMenuItem1
        '
        Me.SobreToolStripMenuItem1.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AQuímicaToolStripMenuItem, Me.OProjetoToolStripMenuItem, Me.ODesenvolvedorToolStripMenuItem})
        Me.SobreToolStripMenuItem1.Image = CType(resources.GetObject("SobreToolStripMenuItem1.Image"), System.Drawing.Image)
        Me.SobreToolStripMenuItem1.Name = "SobreToolStripMenuItem1"
        Me.SobreToolStripMenuItem1.Size = New System.Drawing.Size(167, 22)
        Me.SobreToolStripMenuItem1.Text = "Sobre"
        '
        'AQuímicaToolStripMenuItem
        '
        Me.AQuímicaToolStripMenuItem.Image = CType(resources.GetObject("AQuímicaToolStripMenuItem.Image"), System.Drawing.Image)
        Me.AQuímicaToolStripMenuItem.Name = "AQuímicaToolStripMenuItem"
        Me.AQuímicaToolStripMenuItem.Size = New System.Drawing.Size(164, 22)
        Me.AQuímicaToolStripMenuItem.Text = "A Química"
        '
        'OProjetoToolStripMenuItem
        '
        Me.OProjetoToolStripMenuItem.Image = CType(resources.GetObject("OProjetoToolStripMenuItem.Image"), System.Drawing.Image)
        Me.OProjetoToolStripMenuItem.Name = "OProjetoToolStripMenuItem"
        Me.OProjetoToolStripMenuItem.Size = New System.Drawing.Size(164, 22)
        Me.OProjetoToolStripMenuItem.Text = "A Proposta"
        '
        'ODesenvolvedorToolStripMenuItem
        '
        Me.ODesenvolvedorToolStripMenuItem.Image = CType(resources.GetObject("ODesenvolvedorToolStripMenuItem.Image"), System.Drawing.Image)
        Me.ODesenvolvedorToolStripMenuItem.Name = "ODesenvolvedorToolStripMenuItem"
        Me.ODesenvolvedorToolStripMenuItem.Size = New System.Drawing.Size(164, 22)
        Me.ODesenvolvedorToolStripMenuItem.Text = "O Desenvolvedor"
        '
        'ContatoToolStripMenuItem1
        '
        Me.ContatoToolStripMenuItem1.Image = CType(resources.GetObject("ContatoToolStripMenuItem1.Image"), System.Drawing.Image)
        Me.ContatoToolStripMenuItem1.Name = "ContatoToolStripMenuItem1"
        Me.ContatoToolStripMenuItem1.Size = New System.Drawing.Size(167, 22)
        Me.ContatoToolStripMenuItem1.Text = "Contato"
        '
        'StatusStrip1
        '
        Me.StatusStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripStatusLabel1, Me.ToolStripStatusLabel2, Me.ToolStripStatusLabel3})
        Me.StatusStrip1.Location = New System.Drawing.Point(0, 467)
        Me.StatusStrip1.Name = "StatusStrip1"
        Me.StatusStrip1.Size = New System.Drawing.Size(866, 28)
        Me.StatusStrip1.TabIndex = 2
        Me.StatusStrip1.Text = "StatusStrip1"
        '
        'ToolStripStatusLabel1
        '
        Me.ToolStripStatusLabel1.Font = New System.Drawing.Font("Times New Roman", 15.75!)
        Me.ToolStripStatusLabel1.Name = "ToolStripStatusLabel1"
        Me.ToolStripStatusLabel1.Size = New System.Drawing.Size(197, 23)
        Me.ToolStripStatusLabel1.Text = "ToolStripStatusLabel1"
        '
        'ToolStripStatusLabel2
        '
        Me.ToolStripStatusLabel2.AutoSize = False
        Me.ToolStripStatusLabel2.Font = New System.Drawing.Font("Times New Roman", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ToolStripStatusLabel2.Name = "ToolStripStatusLabel2"
        Me.ToolStripStatusLabel2.Size = New System.Drawing.Size(171, 23)
        Me.ToolStripStatusLabel2.Text = "Sejam Bem-Vindos"
        '
        'ToolStripStatusLabel3
        '
        Me.ToolStripStatusLabel3.Font = New System.Drawing.Font("Times New Roman", 15.75!)
        Me.ToolStripStatusLabel3.Name = "ToolStripStatusLabel3"
        Me.ToolStripStatusLabel3.Size = New System.Drawing.Size(197, 23)
        Me.ToolStripStatusLabel3.Text = "ToolStripStatusLabel3"
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ArquivoToolStripMenuItem, Me.ProjetosToolStripMenuItem, Me.SobreAQuímicaToolStripMenuItem, Me.SobreToolStripMenuItem, Me.ContatoToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(866, 29)
        Me.MenuStrip1.TabIndex = 3
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'ArquivoToolStripMenuItem
        '
        Me.ArquivoToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.SairToolStripMenuItem})
        Me.ArquivoToolStripMenuItem.Font = New System.Drawing.Font("Times New Roman", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ArquivoToolStripMenuItem.Image = CType(resources.GetObject("ArquivoToolStripMenuItem.Image"), System.Drawing.Image)
        Me.ArquivoToolStripMenuItem.Name = "ArquivoToolStripMenuItem"
        Me.ArquivoToolStripMenuItem.Size = New System.Drawing.Size(99, 25)
        Me.ArquivoToolStripMenuItem.Text = "Arquivo"
        '
        'SairToolStripMenuItem
        '
        Me.SairToolStripMenuItem.Image = CType(resources.GetObject("SairToolStripMenuItem.Image"), System.Drawing.Image)
        Me.SairToolStripMenuItem.Name = "SairToolStripMenuItem"
        Me.SairToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.S), System.Windows.Forms.Keys)
        Me.SairToolStripMenuItem.Size = New System.Drawing.Size(169, 26)
        Me.SairToolStripMenuItem.Text = "Sair"
        '
        'ProjetosToolStripMenuItem
        '
        Me.ProjetosToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.TabelaPeriódicaToolStripMenuItem, Me.TabelaDeÂnionsECâtionsToolStripMenuItem})
        Me.ProjetosToolStripMenuItem.Font = New System.Drawing.Font("Times New Roman", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ProjetosToolStripMenuItem.Image = CType(resources.GetObject("ProjetosToolStripMenuItem.Image"), System.Drawing.Image)
        Me.ProjetosToolStripMenuItem.Name = "ProjetosToolStripMenuItem"
        Me.ProjetosToolStripMenuItem.Size = New System.Drawing.Size(100, 25)
        Me.ProjetosToolStripMenuItem.Text = "Projetos"
        '
        'TabelaPeriódicaToolStripMenuItem
        '
        Me.TabelaPeriódicaToolStripMenuItem.Image = CType(resources.GetObject("TabelaPeriódicaToolStripMenuItem.Image"), System.Drawing.Image)
        Me.TabelaPeriódicaToolStripMenuItem.Name = "TabelaPeriódicaToolStripMenuItem"
        Me.TabelaPeriódicaToolStripMenuItem.Size = New System.Drawing.Size(285, 26)
        Me.TabelaPeriódicaToolStripMenuItem.Text = "Tabela Periódica"
        '
        'TabelaDeÂnionsECâtionsToolStripMenuItem
        '
        Me.TabelaDeÂnionsECâtionsToolStripMenuItem.Image = CType(resources.GetObject("TabelaDeÂnionsECâtionsToolStripMenuItem.Image"), System.Drawing.Image)
        Me.TabelaDeÂnionsECâtionsToolStripMenuItem.Name = "TabelaDeÂnionsECâtionsToolStripMenuItem"
        Me.TabelaDeÂnionsECâtionsToolStripMenuItem.Size = New System.Drawing.Size(285, 26)
        Me.TabelaDeÂnionsECâtionsToolStripMenuItem.Text = "Tabela de Ânions e Cátions"
        '
        'SobreAQuímicaToolStripMenuItem
        '
        Me.SobreAQuímicaToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.CalendárioToolStripMenuItem, Me.CálculadoraToolStripMenuItem, Me.ToolStripSeparator1, Me.NotePadToolStripMenuItem, Me.WordToolStripMenuItem, Me.ExcelToolStripMenuItem, Me.ToolStripSeparator2, Me.ExplorerToolStripMenuItem, Me.ChromeToolStripMenuItem, Me.YoutubeToolStripMenuItem})
        Me.SobreAQuímicaToolStripMenuItem.Font = New System.Drawing.Font("Times New Roman", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.SobreAQuímicaToolStripMenuItem.Image = CType(resources.GetObject("SobreAQuímicaToolStripMenuItem.Image"), System.Drawing.Image)
        Me.SobreAQuímicaToolStripMenuItem.Name = "SobreAQuímicaToolStripMenuItem"
        Me.SobreAQuímicaToolStripMenuItem.Size = New System.Drawing.Size(168, 25)
        Me.SobreAQuímicaToolStripMenuItem.Text = "Ferramentas úteis"
        '
        'CalendárioToolStripMenuItem
        '
        Me.CalendárioToolStripMenuItem.Image = CType(resources.GetObject("CalendárioToolStripMenuItem.Image"), System.Drawing.Image)
        Me.CalendárioToolStripMenuItem.Name = "CalendárioToolStripMenuItem"
        Me.CalendárioToolStripMenuItem.Size = New System.Drawing.Size(169, 26)
        Me.CalendárioToolStripMenuItem.Text = "Calendário "
        '
        'CálculadoraToolStripMenuItem
        '
        Me.CálculadoraToolStripMenuItem.Image = CType(resources.GetObject("CálculadoraToolStripMenuItem.Image"), System.Drawing.Image)
        Me.CálculadoraToolStripMenuItem.Name = "CálculadoraToolStripMenuItem"
        Me.CálculadoraToolStripMenuItem.Size = New System.Drawing.Size(169, 26)
        Me.CálculadoraToolStripMenuItem.Text = "Cálculadora"
        '
        'ToolStripSeparator1
        '
        Me.ToolStripSeparator1.Name = "ToolStripSeparator1"
        Me.ToolStripSeparator1.Size = New System.Drawing.Size(166, 6)
        '
        'NotePadToolStripMenuItem
        '
        Me.NotePadToolStripMenuItem.Image = CType(resources.GetObject("NotePadToolStripMenuItem.Image"), System.Drawing.Image)
        Me.NotePadToolStripMenuItem.Name = "NotePadToolStripMenuItem"
        Me.NotePadToolStripMenuItem.Size = New System.Drawing.Size(169, 26)
        Me.NotePadToolStripMenuItem.Text = "Notepad"
        '
        'WordToolStripMenuItem
        '
        Me.WordToolStripMenuItem.Image = CType(resources.GetObject("WordToolStripMenuItem.Image"), System.Drawing.Image)
        Me.WordToolStripMenuItem.Name = "WordToolStripMenuItem"
        Me.WordToolStripMenuItem.Size = New System.Drawing.Size(169, 26)
        Me.WordToolStripMenuItem.Text = "Word"
        '
        'ExcelToolStripMenuItem
        '
        Me.ExcelToolStripMenuItem.Image = CType(resources.GetObject("ExcelToolStripMenuItem.Image"), System.Drawing.Image)
        Me.ExcelToolStripMenuItem.Name = "ExcelToolStripMenuItem"
        Me.ExcelToolStripMenuItem.Size = New System.Drawing.Size(169, 26)
        Me.ExcelToolStripMenuItem.Text = "Excel"
        '
        'ToolStripSeparator2
        '
        Me.ToolStripSeparator2.Name = "ToolStripSeparator2"
        Me.ToolStripSeparator2.Size = New System.Drawing.Size(166, 6)
        '
        'ExplorerToolStripMenuItem
        '
        Me.ExplorerToolStripMenuItem.Image = CType(resources.GetObject("ExplorerToolStripMenuItem.Image"), System.Drawing.Image)
        Me.ExplorerToolStripMenuItem.Name = "ExplorerToolStripMenuItem"
        Me.ExplorerToolStripMenuItem.Size = New System.Drawing.Size(169, 26)
        Me.ExplorerToolStripMenuItem.Text = "Explorer"
        '
        'ChromeToolStripMenuItem
        '
        Me.ChromeToolStripMenuItem.Image = CType(resources.GetObject("ChromeToolStripMenuItem.Image"), System.Drawing.Image)
        Me.ChromeToolStripMenuItem.Name = "ChromeToolStripMenuItem"
        Me.ChromeToolStripMenuItem.Size = New System.Drawing.Size(169, 26)
        Me.ChromeToolStripMenuItem.Text = "Chrome"
        '
        'YoutubeToolStripMenuItem
        '
        Me.YoutubeToolStripMenuItem.Image = CType(resources.GetObject("YoutubeToolStripMenuItem.Image"), System.Drawing.Image)
        Me.YoutubeToolStripMenuItem.Name = "YoutubeToolStripMenuItem"
        Me.YoutubeToolStripMenuItem.Size = New System.Drawing.Size(169, 26)
        Me.YoutubeToolStripMenuItem.Text = "Youtube"
        '
        'SobreToolStripMenuItem
        '
        Me.SobreToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.QuímicaToolStripMenuItem, Me.PropostaToolStripMenuItem, Me.DesenvolvedorToolStripMenuItem})
        Me.SobreToolStripMenuItem.Font = New System.Drawing.Font("Times New Roman", 14.25!)
        Me.SobreToolStripMenuItem.Image = CType(resources.GetObject("SobreToolStripMenuItem.Image"), System.Drawing.Image)
        Me.SobreToolStripMenuItem.Name = "SobreToolStripMenuItem"
        Me.SobreToolStripMenuItem.Size = New System.Drawing.Size(83, 25)
        Me.SobreToolStripMenuItem.Text = "Sobre"
        '
        'QuímicaToolStripMenuItem
        '
        Me.QuímicaToolStripMenuItem.Image = CType(resources.GetObject("QuímicaToolStripMenuItem.Image"), System.Drawing.Image)
        Me.QuímicaToolStripMenuItem.Name = "QuímicaToolStripMenuItem"
        Me.QuímicaToolStripMenuItem.Size = New System.Drawing.Size(211, 26)
        Me.QuímicaToolStripMenuItem.Text = "A Química"
        '
        'PropostaToolStripMenuItem
        '
        Me.PropostaToolStripMenuItem.Image = CType(resources.GetObject("PropostaToolStripMenuItem.Image"), System.Drawing.Image)
        Me.PropostaToolStripMenuItem.Name = "PropostaToolStripMenuItem"
        Me.PropostaToolStripMenuItem.Size = New System.Drawing.Size(211, 26)
        Me.PropostaToolStripMenuItem.Text = "A Proposta"
        '
        'DesenvolvedorToolStripMenuItem
        '
        Me.DesenvolvedorToolStripMenuItem.Image = CType(resources.GetObject("DesenvolvedorToolStripMenuItem.Image"), System.Drawing.Image)
        Me.DesenvolvedorToolStripMenuItem.Name = "DesenvolvedorToolStripMenuItem"
        Me.DesenvolvedorToolStripMenuItem.Size = New System.Drawing.Size(211, 26)
        Me.DesenvolvedorToolStripMenuItem.Text = "O Desenvolvedor"
        '
        'ContatoToolStripMenuItem
        '
        Me.ContatoToolStripMenuItem.Font = New System.Drawing.Font("Times New Roman", 14.25!)
        Me.ContatoToolStripMenuItem.Image = CType(resources.GetObject("ContatoToolStripMenuItem.Image"), System.Drawing.Image)
        Me.ContatoToolStripMenuItem.Name = "ContatoToolStripMenuItem"
        Me.ContatoToolStripMenuItem.Size = New System.Drawing.Size(98, 25)
        Me.ContatoToolStripMenuItem.Text = "Contato"
        '
        'Timer1
        '
        Me.Timer1.Enabled = True
        '
        'FrmPrin
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(866, 495)
        Me.Controls.Add(Me.ToolStrip1)
        Me.Controls.Add(Me.StatusStrip1)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "FrmPrin"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Página Principal "
        Me.ToolStrip1.ResumeLayout(False)
        Me.ToolStrip1.PerformLayout()
        Me.ContextMenuStrip1.ResumeLayout(False)
        Me.StatusStrip1.ResumeLayout(False)
        Me.StatusStrip1.PerformLayout()
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents ToolStrip1 As System.Windows.Forms.ToolStrip
    Friend WithEvents ContextMenuStrip1 As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents StatusStrip1 As System.Windows.Forms.StatusStrip
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents ArquivoToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SairToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SobreAQuímicaToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripStatusLabel1 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents ToolStripStatusLabel2 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents ProjetosToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TabelaPeriódicaToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents TabelaDeÂnionsECâtionsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SobreToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents QuímicaToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PropostaToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DesenvolvedorToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CalendárioToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CálculadoraToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents NotePadToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents WordToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ExcelToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ExplorerToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ChromeToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents YoutubeToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ContatoToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripStatusLabel3 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents ToolStripButton1 As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripSeparator3 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ToolStripButton2 As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripButton3 As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripSeparator4 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ToolStripButton4 As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripButton5 As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripSeparator5 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ToolStripButton6 As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripButton7 As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripButton8 As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripSeparator6 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ToolStripButton9 As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripButton10 As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripButton11 As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripSeparator7 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ToolStripButton12 As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripButton13 As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripButton14 As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripSeparator8 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ToolStripButton15 As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolTip1 As System.Windows.Forms.ToolTip
    Friend WithEvents ArquivoToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SairToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ProjetosToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TabelaPeriódicaToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents FerramentasÚteisToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CalendárioToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CalculadoraToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SobreToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AQuímicaToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents OProjetoToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ODesenvolvedorToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ContatoToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TabelaDeÂnionsECátionsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents NotepadToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents WordToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ExcelToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ExploToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ChromeToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents YoutubeToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
End Class
